﻿Configuration NewDomain             
{             
   param             
    ( 
        [Parameter(Mandatory)]
        [string]$DomainName,            
        [Parameter(Mandatory)]             
        [System.Management.Automation.PSCredential]$SafeModeAdminCreds,             
        [Parameter(Mandatory)]            
        [System.Management.Automation.PSCredential]$AdminCreds            
    )             
            
    Import-DscResource -ModuleName xActiveDirectory 
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)            
            
    Node localhost             
    {             
            
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }            
            
        File ADFiles            
        {            
            DestinationPath = 'C:\NTDS'            
            Type = 'Directory'            
            Ensure = 'Present'            
        }            
                    
        WindowsFeature ADDSInstall             
        {             
            Ensure = "Present"             
            Name = "AD-Domain-Services"             
        }            
            
        # Optional GUI tools            
        WindowsFeature ADDSTools            
        {             
            Ensure = "Present"             
            Name = "RSAT-ADDS"             
        }            
            
        # No slash at end of folder paths            
        xADDomain FirstDS             
        {             
            DomainName = $DomainName             
            DomainAdministratorCredential = $AdminCreds             
            SafemodeAdministratorPassword = $SafeModeAdminCreds            
            DatabasePath = 'C:\NTDS'            
            LogPath = 'C:\NTDS'            
            DependsOn = "[WindowsFeature]ADDSInstall","[File]ADFiles"            
        }            
            
    }             
}